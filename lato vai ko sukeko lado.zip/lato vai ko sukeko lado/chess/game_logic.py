# game_logic.py
import pygame as pg

ROWS, COLS = 8, 8

# Colors for highlights
YELLOW = (255, 255, 0)    # selected
GREEN = (0, 255, 0)       # valid empty
RED = (255, 0, 0)         # capture
BLUE = (0, 0, 255)        # blocked

# Represent pieces as tuples: (color, type)
# color = "w" or "b"
# type = "pawn", "rook", "knight", "bishop", "queen", "king"

def create_board():
    """
    Creates initial chess board with pieces placed correctly.
    """
    board = [[None for _ in range(COLS)] for _ in range(ROWS)]

    # Black pieces
    board[0] = [
        ("b", "rook"), ("b", "knight"), ("b", "bishop"), ("b", "queen"),
        ("b", "king"), ("b", "bishop"), ("b", "knight"), ("b", "rook")
    ]
    board[1] = [("b", "pawn") for _ in range(COLS)]

    # White pieces
    board[6] = [("w", "pawn") for _ in range(COLS)]
    board[7] = [
        ("w", "rook"), ("w", "knight"), ("w", "bishop"), ("w", "queen"),
        ("w", "king"), ("w", "bishop"), ("w", "knight"), ("w", "rook")
    ]

    return board


def inside_board(r, c):
    return 0 <= r < ROWS and 0 <= c < COLS


def get_piece_moves(board, row, col):
    """
    Returns moves for a piece at given row,col:
    - green squares = valid empty moves
    - red squares = valid captures
    - blue squares = blocked by same color
    """
    piece = board[row][col]
    if not piece:
        return [], [], []

    color, p_type = piece
    moves, captures, blocked = [], [], []

    directions = []

    if p_type == "pawn":
        direction = -1 if color == "w" else 1
        start_row = 6 if color == "w" else 1

        # Forward move
        if inside_board(row + direction, col) and board[row + direction][col] is None:
            moves.append((row + direction, col))
            # Double move
            if row == start_row and board[row + 2*direction][col] is None:
                moves.append((row + 2*direction, col))

        # Captures
        for dc in [-1, 1]:
            nr, nc = row + direction, col + dc
            if inside_board(nr, nc):
                if board[nr][nc] and board[nr][nc][0] != color:
                    captures.append((nr, nc))
                elif board[nr][nc] and board[nr][nc][0] == color:
                    blocked.append((nr, nc))

    elif p_type == "rook":
        directions = [(1,0), (-1,0), (0,1), (0,-1)]
    elif p_type == "bishop":
        directions = [(1,1), (1,-1), (-1,1), (-1,-1)]
    elif p_type == "queen":
        directions = [(1,0), (-1,0), (0,1), (0,-1), (1,1), (1,-1), (-1,1), (-1,-1)]
    elif p_type == "king":
        for dr in [-1,0,1]:
            for dc in [-1,0,1]:
                if dr == 0 and dc == 0: continue
                nr, nc = row+dr, col+dc
                if inside_board(nr, nc):
                    if board[nr][nc] is None:
                        moves.append((nr,nc))
                    elif board[nr][nc][0] != color:
                        captures.append((nr,nc))
                    else:
                        blocked.append((nr,nc))
    elif p_type == "knight":
        knight_moves = [(2,1),(2,-1),(-2,1),(-2,-1),(1,2),(1,-2),(-1,2),(-1,-2)]
        for dr,dc in knight_moves:
            nr, nc = row+dr, col+dc
            if inside_board(nr,nc):
                if board[nr][nc] is None:
                    moves.append((nr,nc))
                elif board[nr][nc][0] != color:
                    captures.append((nr,nc))
                else:
                    blocked.append((nr,nc))

    # Handle sliding pieces (rook, bishop, queen)
    if directions:
        for dr, dc in directions:
            nr, nc = row+dr, col+dc
            while inside_board(nr,nc):
                if board[nr][nc] is None:
                    moves.append((nr,nc))
                elif board[nr][nc][0] != color:
                    captures.append((nr,nc))
                    break
                else:
                    blocked.append((nr,nc))
                    break
                nr += dr
                nc += dc

    return moves, captures, blocked
